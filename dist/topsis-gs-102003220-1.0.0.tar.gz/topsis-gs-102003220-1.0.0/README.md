# Topsis Implimentation by Gurtaran
It takes a csv file, weigths of all columns, impacts as 1 for positive and -1 for negative and output file name as an input and give the final topsis implimented file out.

## Installation
```pip install topsis-gs-102003220```

## How to use it?
Open terminal and type file path, weights, impact as 1 or -1 and output file name.

## License

© 2023 Gurtaran Singh

This repository is licensed under the MIT license. See LICENSE for details.
